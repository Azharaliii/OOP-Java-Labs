public class BankAccount {
    String accountNumber;
    String accountHolderName;
    double balance;

    // Constructor
    BankAccount(String an, String accountHolderName, double initialBalance) {
        this.accountNumber = an;
        this.accountHolderName = accountHolderName;
        this.balance = initialBalance;
    }
    // Constructor
    BankAccount(String an, double initialBalance) {
        this.accountNumber = an;
        // this.accountHolderName = accountHolderName;
        this.balance = initialBalance;
    }
    // Method to deposit funds
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposit of $" + amount + " successful.");
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // Method to withdraw funds
    void withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawal of $" + amount + " successful.");
        } else {
            System.out.println("Insufficient funds or invalid withdrawal amount.");
        }
    }

    // Method to display account information
    void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Holder Name: " + accountHolderName);
        System.out.println("Current Balance: $" + balance);
        System.out.println();
        
    }

    public static void main(String[] args) {
        // Example usage
        BankAccount account = new BankAccount("123456789", "John Doe", 1000.0);
        BankAccount account2 = new BankAccount("2345678", 1000.0);
        
        account.displayAccountInfo(); // Display initial account information

        // Deposit $500
        account.deposit(500.0);
        account.displayAccountInfo(); // Display updated account information
        // Withdraw $200
        account.withdraw(200.0);
        account.displayAccountInfo(); // Display updated account information
        // Withdraw $2000 (Insufficient funds)
        account.withdraw(2000.0);
        account.displayAccountInfo(); // Display unchanged account information
    }
}
