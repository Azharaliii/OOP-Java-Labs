import java.util.Random;

public class RandomPasswordGenerator {
    // Characters to be used in the password
    static String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+";

    public static void main(String[] args) {

        int length = 10; // specify the length of the password
        
        StringBuilder password = new StringBuilder();
        Random random = new Random();

        // Generate random characters for the password
        for (int i = 0; i < length; i++) {
           // int randomIndex = random.nextInt(CHARACTERS.length());
            random = ((int)Math.random()*100)-min;
            char randomChar = CHARACTERS.charAt(randomIndex);
            password.append(randomChar);
        }

        System.out.println("Generated Password: " + password.toString());
    }
}
