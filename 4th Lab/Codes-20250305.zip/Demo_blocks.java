import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // Label for the block of code
        Scanner sc = new Scanner(System.in);
		String s = "Nimra";
		int x= sc.nextInt();
		failBlock: {
            System.out.println("Inside the block of code");
            // Break statement to exit the block of code
            if(x>=60){
			goto passBlock;
			}
            // This code will not be executed due to the break statement
            System.out.println("Fail");
			System.out.println("This code will not be executed if condition is true");
        }
		passBlock:{
        	System.out.println("Outside the block of code");
			}
	}
}
