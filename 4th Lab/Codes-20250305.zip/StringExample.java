import java.util.Scanner;

public class StringExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking input from the user
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();

        // Displaying the input string
        System.out.println("\nInput string: " + inputString);

        // String length
        int length = inputString.length();
        System.out.println("Length of the string: " + length);

        // Converting to uppercase and lowercase
        String upperCaseString = inputString.toUpperCase();
        String lowerCaseString = inputString.toLowerCase();
        System.out.println("Uppercase: " + upperCaseString);
        System.out.println("Lowercase: " + lowerCaseString);

        // Checking if the string contains a substring
        System.out.print("\nEnter a substring to search: ");
        String substring = scanner.nextLine();
        boolean containsSubstring = inputString.contains(substring);
        System.out.println("Does the string contain '" + substring + "'? " + containsSubstring);

        // Finding the index of a substring
        if (containsSubstring) {
            int index = inputString.indexOf(substring);
            System.out.println("Index of '" + substring + "': " + index);
        }

        // Replacing characters
        System.out.print("\nEnter a character to replace: ");
        char oldChar = scanner.next().charAt(0); // Read first character of input
        System.out.print("Enter a character to replace with: ");
        char newChar = scanner.next().charAt(0); // Read first character of input
        String replacedString = inputString.replace(oldChar, newChar);
        System.out.println("String after replacement: " + replacedString);

        // Splitting the string
        System.out.print("\nEnter a delimiter to split the string: ");
        String delimiter = scanner.next();
        String[] parts = inputString.split(delimiter);
        System.out.println("Splitting the string with '" + delimiter + "': ");
        for (String part : parts) {
            System.out.println(part);
        }

        // Substring extraction
        System.out.print("\nEnter start index for substring extraction: ");
        int startIndex = scanner.nextInt();
        System.out.print("Enter end index for substring extraction: ");
        int endIndex = scanner.nextInt();
        String extractedSubstring = inputString.substring(startIndex, endIndex);
        System.out.println("Extracted substring: " + extractedSubstring);

        // Checking if the string is empty or null
        System.out.println("\nIs the string empty? " + inputString.isEmpty());
        System.out.println("Is the string null? " + (inputString == null));

        // Closing the scanner
        scanner.close();
    }
}
