import java.util.Scanner;
import java.util.Random;

class MovieTheater {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Ask user for number of rows
        System.out.print("Enter the number of rows in the theater: ");
        int rows = scanner.nextInt();

        // Create a jagged array
        boolean[][] seats = new boolean[rows][];

        // Ask user for the number of seats in each row
        for (int i = 0; i < rows; i++) {
            System.out.print("Enter the number of seats in row " + (i + 1) + ": ");
            int seatsInRow = scanner.nextInt();
            seats[i] = new boolean[seatsInRow];

            // Randomly mark some seats as booked
            for (int j = 0; j < seatsInRow; j++) {
                seats[i][j] = random.nextBoolean(); // Randomly set true (available) or false (booked)
            }
        }

        // Display the seating arrangement
        System.out.println("\nMovie Theater Seating Arrangement:");
        for (int i = 0; i < seats.length; i++) {
            System.out.print("Row " + (i + 1) + ": ");
            for (boolean seat : seats[i]) {
                System.out.print(seat ? "[Available] " : "[Booked] ");
            }
            System.out.println();
        }

        scanner.close();
    }
}
