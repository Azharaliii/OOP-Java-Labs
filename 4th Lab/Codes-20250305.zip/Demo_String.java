/*
This code is created to demonstrate "String pool" in the heap memory
Before Executing This code
You must be aware of the Heap and Stack memory concept
You will also understand Immutable Strings*/

public class Demo_String {
    public static void main(String args[])  {
        // String s1 = new String("Nimra");
        // String s2 = new String("Nimra");
        StringBuilder s1 = new StringBuilder("Nimra");

        // System.out.println(s1  == s2); // This statement will return Fa
   
        // String are Immutable... Let's see
        System.out.println("Before append: " + s1 + ": " + s1.hashCode());
        s1.append(" Mughal"); 
        System.out.println("After append: " + s1 + ": " + s1.hashCode());
        // Hashes are different before and  after append

    }
}
