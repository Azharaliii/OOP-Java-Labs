public class PrintfExample {
    public static void main(String[] args) {
        String name = "John";
        int age = 30;
        double height = 6.1;

        System.out.printf("Name: %-10s, Age: %-10d, Height: %10.1f\n", name, age, height);
        System.out.println();
        // Format strings to be placed in fixed width
        // System.out.printf("Name: %-10s, Age: %-5d, Height: %-5.1f\n", name, age, height);

        // double d = 4.5;

        // System.out.println(d);
        // // Shows 2 digits after the decimal point
        // System.out.println(String.format("floatValue: %.2f", d)); // Shows 2 digits after the decimal point

    }
}
