import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;      
// main method   
class AggregationExample  
{   
    public static void main (String[] args)    
    {   
        Student std1 = new Student("Emma", 1801, "MCA");   
        Student std2 = new Student("Adele", 1802, "BSC-CS");   
        Student std3 = new Student("Aria", 1803, "Poly");   
        Student std4 = new Student("Ally", 1804, "MCA");   
        Student std5 = new Student("Paul", 1805, "Poly");         
          
        // Constructing list of MCA Students.   
        List <Student> mca_students = new ArrayList<Student>();   
        mca_students.add(std1);   
        mca_students.add(std4); 
        mca_students.add(new Student("Tom", 1809, "MCA")); 
          
            
        //Constructing list of BSC-CS Students.   
        List <Student> bsc_cs_students = new ArrayList<Student>();   
        bsc_cs_students.add(std2);   
          
        //Constructing list of Poly Students.   
        List <Student> poly_students = new ArrayList<Student>();   
        poly_students.add(std3);   
        poly_students.add(std5);   
            
        Course MCA = new Course("MCA", mca_students);   
        Course BSC_CS = new Course("BSC-CS", bsc_cs_students);  
        Course Poly = new Course("Poly", poly_students);   
            
        
        System.out.println("\nAll Students of MCA");
        for (Student s: MCA.studentsData()){
                System.out.println(s.name+"\t"+s.enrol+"\t"+s.degree);

        }
        //display the students of BSC_CS
        System.out.println("\nAll Students of Poly");
        for (Student s: Poly.studentsData()){
            System.out.println(s.name+"\t"+s.enrol+"\t"+s.degree);
        }
        //display the students of Poly with some search criteria
        //display the criteria
        System.out.println("\nStudents of Poly with enrol 1805");
        for (Student s: Poly.studentsData()){
            if (s.enrol == 1805){
                System.out.println(s.name+"\t"+s.enrol+"\t"+s.degree);

            }
        }
        //display the student of bccs whose name starts with A
        System.out.println("\nStudents whose name starts with A");
        for (Student s: BSC_CS.studentsData()){
            if (s.name.startsWith("A")){
                System.out.println(s.name+"\t"+s.enrol+"\t"+s.degree);

            }
        }
    }   
} 