// Student class   
class Student 
{   
    String name;   
    int enrol ;   
    String degree;   
        
    Student(String name, int enrol, String degree)    
    {   
            
        this.name = name;   
        this.enrol = enrol;   
        this.degree = degree;   
    }   
}   
    
