package gadgets;

public class Laptop {
    public void boot() {
        System.out.println("Laptop is booting up...");
    }
}
