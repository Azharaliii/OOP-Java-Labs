package gadgets;

public class Smartphone {
    public void call() {
        System.out.println("Smartphone is calling...");
    }
}
