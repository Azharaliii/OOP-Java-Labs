import animals.Dog;
import animals.Cat;
import vehicles.Car;
import vehicles.Bike;
import gadgets.Smartphone;
import gadgets.Laptop;

public class PackagePractice {
    public static void main(String[] args) {
        // Animals
        Dog dog = new Dog();
        dog.bark();

        Cat cat = new Cat();
        cat.meow();

        // Vehicles
        Car car = new Car();
        car.drive();

        Bike bike = new Bike();
        bike.ride();

        // Gadgets
        Smartphone smartphone = new Smartphone();
        smartphone.call();

        Laptop laptop = new Laptop();
        laptop.boot();
    }
}
