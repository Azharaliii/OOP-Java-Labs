package animals;

public class Dog {
    public void bark() {
        System.out.println("Dog says: Woof!");
    }
}
