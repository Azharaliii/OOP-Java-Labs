package animals;

public class Cat {
    public void meow() {
        System.out.println("Cat says: Meow!");
    }
}
