package vehicles;

public class Bike {
    public void ride() {
        System.out.println("Bike is riding!");
    }
}
